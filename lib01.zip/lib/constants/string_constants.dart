class Stringconstraints {
  static const appName = 'Flutter Task';
  static const loginbtn = 'Submit';
  static const hint_login_entermobilenum = 'Enter Mobile number';
  static const error_login_entermobilenum = 'Enter Valid Mobile number';

  static const hint_login_enterpassword = 'Enter Six Digit OTP';
  static const error_login_enterpassword = 'Enter Valid OTP';
  static const enterOTP = 'Enter OTP';

  static const txtsearch = 'Search ...';
}
