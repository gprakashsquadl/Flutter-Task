import 'package:flutter/material.dart';

class ColorConstraints {
  static Color bg_splashscreen = const Color(0xFFD3D3D3);
  static Color bg_homescreen = const Color(0xFFe0f2f1);

  static Color welcomeCarouselCurrentSlide = const Color(0xFF000000);
  static Color loginbtn = const Color(0xFF000000);
}
